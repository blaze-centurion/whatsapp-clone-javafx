-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2021 at 07:03 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `whatsapp-clone`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int(10) NOT NULL,
  `senderId` int(10) NOT NULL,
  `receiverId` int(10) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `file` varchar(45) DEFAULT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(5) NOT NULL,
  `networkStatus` int(1) NOT NULL DEFAULT 0,
  `seen` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `senderId`, `receiverId`, `msg`, `file`, `date`, `time`, `networkStatus`, `seen`) VALUES
(66, 688956001, 897151753, 'hey', NULL, '15/10/2021', '10:25', 0, NULL),
(67, 688956001, 897151753, 'hello, I am roshan', NULL, '15/10/2021', '10:25', 0, NULL),
(68, 688956001, 897151753, 'how are you', NULL, '15/10/2021', '10:25', 0, NULL),
(69, 688956001, 897151753, 'how are you', NULL, '15/10/2021', '10:26', 0, NULL),
(70, 688956001, 897151753, 'hi', NULL, '15/10/2021', '10:26', 0, NULL),
(71, 688956001, 897151753, 'how are you', NULL, '15/10/2021', '10:26', 0, NULL),
(72, 897151753, 688956001, 'hello roshan', NULL, '15/10/2021', '10:28', 0, NULL),
(73, 897151753, 688956001, 'i am fine', NULL, '15/10/2021', '10:28', 0, NULL),
(74, 688956001, 897151753, 'ohh nice to hear this', NULL, '15/10/2021', '10:29', 0, NULL),
(75, 897151753, 688956001, 'long time no see', NULL, '15/10/2021', '10:29', 0, NULL),
(76, 897151753, 688956001, 'where are you right now', NULL, '15/10/2021', '10:29', 0, NULL),
(77, 688956001, 897151753, 'ohh yaa', NULL, '15/10/2021', '10:29', 0, NULL),
(78, 688956001, 897151753, 'I am so busy these days', NULL, '15/10/2021', '10:29', 0, NULL),
(79, 688956001, 897151753, 'I am in usa right now', NULL, '15/10/2021', '10:29', 0, NULL),
(80, 897151753, 688956001, 'ohh nive', NULL, '15/10/2021', '10:29', 0, NULL),
(81, 897151753, 688956001, 'Whenever you will come India, please contact me. We will enjoy together', NULL, '15/10/2021', '10:30', 0, NULL),
(82, 688956001, 897151753, 'sure', NULL, '15/10/2021', '10:30', 0, NULL),
(83, 688956001, 897151753, 'btw i am in India', NULL, '15/10/2021', '10:31', 0, NULL),
(84, 688956001, 897151753, 'right now. I was just joking', NULL, '15/10/2021', '10:31', 0, NULL),
(85, 897151753, 688956001, 'ohh nice jok', NULL, '15/10/2021', '10:31', 0, NULL),
(86, 897151753, 688956001, '*joke', NULL, '15/10/2021', '10:31', 0, NULL),
(87, 688956001, 897151753, 'hmm', NULL, '15/10/2021', '10:31', 0, NULL),
(88, 688956001, 897151753, 'ok bye', NULL, '15/10/2021', '10:31', 0, NULL),
(89, 897151753, 688956001, 'ohh', NULL, '15/10/2021', '10:31', 0, NULL),
(90, 897151753, 688956001, 'ok bye', NULL, '15/10/2021', '10:31', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) NOT NULL,
  `userId` int(10) NOT NULL,
  `contactId` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `userId`, `contactId`) VALUES
(2, 422523965, 688956001),
(4, 688956001, 897151753),
(5, 897151753, 688956001),
(7, 422523965, 688956001);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `whatsappId` int(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(150) NOT NULL,
  `userProfile` varchar(150) NOT NULL DEFAULT 'images/user.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `whatsappId`, `email`, `password`, `userProfile`) VALUES
(1, 'Roshan', 688956001, 'roshan@mail.com', '$2a$12$3mii3/Js4aIaYV0ydH13P.6LjQiRh9GURwRaconk9jmaFNr9PN.wO', 'images/user.png'),
(3, 'sameer', 422523965, 'sameer@mail.com', '$2a$12$DHoICUyk2MfiKBwf5SqJquueim9jJkztYlErNifcBdOPNVTJI1PSS', 'images/user.png'),
(4, 'Anil  - Champ', 897151753, 'anil@mail.com', '$2a$12$LZ6PI3u0UgZzgpQY563cfOrinEC/t35aGzELhEYHMQWNt20T9Q3le', 'images/user.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
